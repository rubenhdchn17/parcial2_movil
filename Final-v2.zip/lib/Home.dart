import 'package:flutter/material.dart';
import 'package:final_v1/Site_information.dart';

void main() {
  runApp(MyApp());
}

class Tienda {
  final String nombre;
  final double calificacion;
  final String categoria;
  final String imagen;

  Tienda({
    required this.nombre,
    required this.calificacion,
    required this.categoria,
    required this.imagen,
  });
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Tiendas',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(
            color: Color(0xff0d8cf4),
          ),
        ),
      ),
      home: Home(),
    );
  }
}

class Home extends StatelessWidget {
  List<Tienda> tiendas = [
    Tienda(
      nombre: 'Olimpica',
      calificacion: 4.5,
      categoria: 'Supermercado',
      imagen: 'assets/olimpica.png',
    ),
    Tienda(
      nombre: 'Tienda 2',
      calificacion: 4.0,
      categoria: 'Electrónicos',
      imagen: 'assets/olimpica.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi App de Tiendas'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.grey[200],
              ),
              child: TextField(
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Buscar tiendas',
                  prefixIcon: Icon(Icons.search),
                  contentPadding: EdgeInsets.symmetric(horizontal: 15),
                ),
                onChanged: (value) {},
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                child: Text('Restaurante'),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                child: Text('Moda'),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                child: Text('Supermercado'),
              ),
            ],
          ),
          SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: tiendas.length,
              itemBuilder: (context, index) {
                Tienda tienda = tiendas[index];
                return ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => site_information(),
                      ),
                    );
                  },
                  leading: Container(
                    width: 60.0,
                    height: 60.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage(tienda.imagen),
                      ),
                    ),
                  ),
                  title: Text(tienda.nombre),
                  subtitle: Text(
                    'Calificación: ${tienda.calificacion}, Categoría: ${tienda.categoria}',
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
