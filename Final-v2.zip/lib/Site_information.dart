import 'package:flutter/material.dart';

class TiendaDetalle extends StatelessWidget {
  final String nombreTienda;
  final double calificacion;
  final String categoria;
  final String imagen;

  TiendaDetalle({
    required this.nombreTienda,
    required this.calificacion,
    required this.categoria,
    required this.imagen,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(nombreTienda),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: double.infinity,
            height: MediaQuery.of(context).size.height * 0.3,
            decoration: BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage(imagen),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star_half, color: Colors.yellow),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            child: Text('Opiniones'),
          ),
          Container(
            color: Colors.grey,
            padding: EdgeInsets.all(16.0),
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    'Descripción de la tienda...',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () {},
                  child: Text('Ir'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
