import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _switchValue = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Página de inicio'),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16, top: 16),
            child: SwitchButton(
              switchValue: _switchValue,
              onChanged: (value) {
                setState(() {
                  _switchValue = value;
                });
              },
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            LocationStatusWidget(isLocationActive: _switchValue),
          ],
        ),
      ),
    );
  }
}

class SwitchButton extends StatefulWidget {
  final bool switchValue;
  final ValueChanged<bool> onChanged;

  SwitchButton({required this.switchValue, required this.onChanged});

  @override
  _SwitchButtonState createState() => _SwitchButtonState();
}

class _SwitchButtonState extends State<SwitchButton> {
  @override
  Widget build(BuildContext context) {
    return Switch(
      value: widget.switchValue,
      onChanged: widget.onChanged,
      activeColor: Colors.blue,
    );
  }
}

class LocationStatusWidget extends StatelessWidget {
  final bool isLocationActive;

  LocationStatusWidget({required this.isLocationActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200, // Ancho del cuadro
      height: 100, // Altura del cuadro
      decoration: BoxDecoration(
        borderRadius:
            BorderRadius.circular(10), // Bordes redondeados del cuadro
        color: isLocationActive
            ? Colors.green
            : Colors.red, // Color del cuadro según el estado de la localización
      ),
      child: Center(
        child: Text(
          isLocationActive ? 'Localización activada' : 'Active la localización',
          style: TextStyle(
            color: Colors.white, // Color del texto dentro del cuadro
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
