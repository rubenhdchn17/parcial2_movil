import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _switchValue = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Página de inicio'),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16, top: 16),
            child: SwitchButton(
              switchValue: _switchValue,
              onChanged: (value) {
                setState(() {
                  _switchValue = value;
                });
              },
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Parte superior con la imagen (se mostrará solo si la ubicación está activada)
          if (_switchValue)
            Expanded(
              flex: 1,
              child: Container(
                // Puedes reemplazar 'assets/tu_imagen.jpg' con tu imagen deseada
                child: Image.asset(
                  'assets/tu_imagen.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          // Botones horizontales (se mostrarán solo si la ubicación está activada)
          if (_switchValue)
            Column(
              children: [
                SizedBox(height: 16), // Espacio entre la imagen y los botones
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Acción del primer botón
                      },
                      child: Text('Botón 1'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Acción del segundo botón
                      },
                      child: Text('Botón 2'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Acción del tercer botón
                      },
                      child: Text('Botón 3'),
                    ),
                  ],
                ),
              ],
            ),
          // Parte inferior con las tiendas o el mensaje de ubicación
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: _switchValue
                  ? StoreDescriptions()
                  : LocationStatusWidget(isLocationActive: _switchValue),
            ),
          ),
        ],
      ),
    );
  }
}

class SwitchButton extends StatefulWidget {
  final bool switchValue;
  final ValueChanged<bool> onChanged;

  SwitchButton({required this.switchValue, required this.onChanged});

  @override
  _SwitchButtonState createState() => _SwitchButtonState();
}

class _SwitchButtonState extends State<SwitchButton> {
  @override
  Widget build(BuildContext context) {
    return Switch(
      value: widget.switchValue,
      onChanged: widget.onChanged,
      activeColor: Colors.blue,
    );
  }
}

class LocationStatusWidget extends StatelessWidget {
  final bool isLocationActive;

  LocationStatusWidget({required this.isLocationActive});

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: !isLocationActive,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.red,
        ),
        child: Center(
          child: Text(
            'Active la localización',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class StoreDescriptions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: <Widget>[
          StoreDescription(
            storeName: 'Tienda 1',
            description: 'Esta es la descripción de la Tienda 1.',
            rating: 4.5,
            hours: '9:00 AM - 6:00 PM',
            image: 'assets/store1.jpg',
          ),
          SizedBox(height: 16),
          StoreDescription(
            storeName: 'Tienda 2',
            description: 'Esta es la descripción de la Tienda 2.',
            rating: 4.0,
            hours: '10:00 AM - 8:00 PM',
            image: 'assets/store2.jpg',
          ),
          SizedBox(height: 16),
          StoreDescription(
            storeName: 'Tienda 3',
            description: 'Esta es la descripción de la Tienda 3.',
            rating: 3.8,
            hours: '8:30 AM - 7:00 PM',
            image: 'assets/store3.jpg',
          ),
          // Add more store descriptions as needed
        ],
      ),
    );
  }
}

class StoreDescription extends StatelessWidget {
  final String storeName;
  final String description;
  final double rating;
  final String hours;
  final String image;

  StoreDescription({
    required this.storeName,
    required this.description,
    required this.rating,
    required this.hours,
    required this.image,
  });

  void _showDetails(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Detalles de $storeName'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showDetails(context),
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagen de la tienda
            Image.asset(
              image,
              height: 100,
              width: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(width: 16), // Espaciado entre la imagen y la información
            // Información de la tienda
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    storeName,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('Calificación: $rating'),
                  Text('Horarios: $hours'),
                  Text('Descripción: $description'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
