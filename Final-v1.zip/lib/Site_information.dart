import 'package:flutter/material.dart';

class TiendaDetalle extends StatelessWidget {
  final String nombreTienda;

  // Puedes pasar más datos de la tienda según sea necesario

  TiendaDetalle({required this.nombreTienda});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(nombreTienda),
      ),
      body: Center(
        child: Text('Detalles de la tienda $nombreTienda'),
      ),
    );
  }
}
