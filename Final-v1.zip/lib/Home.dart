import 'package:flutter/material.dart';
import 'package:final_v1/Site_information.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(
            color: Color(0xff0d8cf4),
          ),
        ),
      ),
      home: Home(),
    );
  }
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi App de Login'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Buscar tiendas',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {},
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  child: Text('Restaurante'),
                ),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                child: Text('Moda'),
              ),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                ),
                child: Text('Supermercado'),
              ),
            ],
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.2),
          Container(
            height: MediaQuery.of(context).size.height * 0.2,
            color: Colors.grey,
          ),
          SizedBox(height: 10),
          Expanded(
            child: SizedBox(
              child: ListView.builder(
                itemCount: 5, // Número de tiendas
                itemBuilder: (context, index) {
                  // Aquí debes proporcionar la información de cada tienda
                  return ListTile(
                    onTap: () {
                      // Navegar a la pantalla de detalles cuando se presiona la tienda
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TiendaDetalle(
                              nombreTienda: 'Nombre de la tienda $index'),
                        ),
                      );
                    },
                    leading: Container(
                      width: 60.0,
                      height: 60.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage(
                            'ruta_de_la_imagen.jpg', // Agrega la ruta de la imagen
                          ),
                        ),
                      ),
                    ),
                    title: Text('Nombre de la tienda $index'),
                    subtitle: Text('Calificación: 4.5, Categoría: Ropa'),
                    // Otros detalles de la tienda
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
