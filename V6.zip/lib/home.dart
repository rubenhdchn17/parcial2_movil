import 'package:flutter/material.dart';
import 'shop1.dart';
import 'shop2.dart';
import 'shop3.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(
              color:
                  Color(0xff0d8cf4)), // Cambia el color del icono de retroceso
        ),
      ),
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _switchValue = false;
  String _currentImage = 'assets/mapa.png';
  bool _modaActivated = false;
  bool _electronicaActivated = false;
  bool _comidaActivated = false;

  void _switchImage(String imagePath) {
    setState(() {
      _currentImage = imagePath;
      _modaActivated = false;
      _electronicaActivated = false;
      _comidaActivated = false;
      if (imagePath == 'assets/moda.png') {
        _modaActivated = true;
      } else if (imagePath == 'assets/electronica.png') {
        _electronicaActivated = true;
      } else if (imagePath == 'assets/comida.png') {
        _comidaActivated = true;
      }
    });
  }

  void _showLocationWarning() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Advertencia de ubicación'),
          content: Text('Por favor, active la ubicación para continuar.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white.withOpacity(0.8),
        title: Text(''),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16, top: 16),
            child: SwitchButton(
              switchValue: _switchValue,
              onChanged: (value) {
                setState(() {
                  _switchValue = value;
                  if (!_switchValue) {
                    _showLocationWarning();
                  }
                });
              },
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_switchValue)
            Expanded(
              flex: 1,
              child: Container(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.asset(
                    _currentImage,
                    fit: BoxFit.cover,
                    width: 330,
                    height: 120,
                  ),
                ),
              ),
            ),

          // Botones horizontales
          if (_switchValue)
            Column(
              children: [
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        if (_modaActivated) {
                          _switchImage('assets/mapa.png');
                        } else {
                          _switchImage('assets/moda.png');
                        }
                      },
                      child: Text(_modaActivated ? 'Moda' : 'Moda'),
                      style: ElevatedButton.styleFrom(
                        primary: Color(
                            0xFF4285F4), // Color base del botón (azul opaco
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (_electronicaActivated) {
                          _switchImage('assets/mapa.png');
                        } else {
                          _switchImage('assets/electronica.png');
                        }
                      },
                      child: Text(_electronicaActivated
                          ? 'Electrónica'
                          : 'Electrónica'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (_comidaActivated) {
                          _switchImage('assets/mapa.png');
                        } else {
                          _switchImage('assets/comida.png');
                        }
                      },
                      child: Text(_comidaActivated ? 'Comida' : 'Comida'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: _switchValue
                  ? StoreDescriptions()
                  : LocationStatusWidget(isLocationActive: _switchValue),
            ),
          ),
        ],
      ),
      backgroundColor: Color.fromRGBO(255, 255, 255, 0.9),
    );
  }
}

class SwitchButton extends StatefulWidget {
  final bool switchValue;
  final ValueChanged<bool> onChanged;

  SwitchButton({required this.switchValue, required this.onChanged});

  @override
  _SwitchButtonState createState() => _SwitchButtonState();
}

class _SwitchButtonState extends State<SwitchButton> {
  @override
  Widget build(BuildContext context) {
    return Switch(
      value: widget.switchValue,
      onChanged: widget.onChanged,
      activeColor: Color(0xd900b8ff),
    );
  }
}

class LocationStatusWidget extends StatelessWidget {
  final bool isLocationActive;

  LocationStatusWidget({required this.isLocationActive});

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: !isLocationActive,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Color(0xffffffff),
        ),
        child: Center(
          child: Text(
            'Active la localización',
            style: TextStyle(
              color: Color(0xff000000),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class StoreDescriptions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: <Widget>[
          StoreDescription(
            storeName: 'SuperDroguería Olímpica 93',
            description: 'Precios siempre bajos',
            rating: 4.5,
            hours: '24 horas',
            image: 'assets/olimpica.png',
          ),
          SizedBox(height: 16),
          StoreDescription(
            storeName: 'Tienda D1',
            description: '¡Si lo quieres, lo tienes!',
            rating: 4.0,
            hours: '7:00 AM - 9:00 PM',
            image: 'assets/d1.png',
          ),
          SizedBox(height: 16),
          StoreDescription(
            storeName: "McDonald's",
            description: 'Me encanta',
            rating: 4.5,
            hours: '24 horas',
            image: 'assets/mc.png',
          ),
          SizedBox(height: 16),
          Container(
            height: 50,
            child: Image.asset(
              'assets/anuncio.png',
              height: 300,
              width: 350,
              fit: BoxFit.contain,
            ),
          ),
        ],
      ),
    );
  }
}

class StoreDescription extends StatelessWidget {
  final String storeName;
  final String description;
  final double rating;
  final String hours;
  final String image;

  StoreDescription({
    required this.storeName,
    required this.description,
    required this.rating,
    required this.hours,
    required this.image,
  });

  void _showDetails(BuildContext context) {
    if (storeName == 'SuperDroguería Olímpica 93') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Shop1Page()),
      );
    } else if (storeName == 'Tienda D1') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Shop2Page()),
      );
    } else if (storeName == "McDonald's") {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Shop3Page()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showDetails(context),
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagen de la tienda
            Image.asset(
              image,
              height: 100,
              width: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(width: 16),
            // Información de la tienda
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    storeName,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('Calificación: $rating'),
                  Text('$hours'),
                  Text('$description'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
