import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Shop3Page(),
    );
  }
}

class Shop3Page extends StatefulWidget {
  @override
  _Shop3PageState createState() => _Shop3PageState();
}

class _Shop3PageState extends State<Shop3Page> {
  bool isRouteMarked = false;
  String markedImagePath = 'assets/marcadaMc.png';
  String unmarkedImagePath = 'assets/mapa.png';

  String get currentImagePath =>
      isRouteMarked ? markedImagePath : unmarkedImagePath;

  void toggleRouteMarked() {
    setState(() {
      isRouteMarked = !isRouteMarked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white.withOpacity(0.8),
        title: Center(
            child:
                Text('McDonald´s', style: TextStyle(color: Color(0xff000000)))
            // Cambia el color del texto del título aquí
            ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 20),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(
                  currentImagePath,
                  fit: BoxFit.cover,
                  width: 330,
                  height: 330,
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              width: 330,
              decoration: BoxDecoration(
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(20),
              ),
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "McDonald's Barranquilla Calle 93",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Ven ya al a McDonald's y entérate de todo lo nuevo que tenemos para ti este mes.",
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Dirección de la tienda: Cl 93 - #47 - 2',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Abierto: 24 horas',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Image.asset(
                    'assets/anuncioMc.png',
                    height: 120,
                    width: 300,
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.blue,
              ),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              child: ElevatedButton(
                onPressed: () {
                  toggleRouteMarked();
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  shadowColor: Colors.transparent,
                ),
                child: Text(
                  isRouteMarked ? 'Desmarcar Ruta' : 'Marcar Ruta',
                  style: TextStyle(color: Colors.white, fontSize: 22),
                ),
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Color.fromRGBO(255, 255, 255, 0.9),
    );
  }
}
