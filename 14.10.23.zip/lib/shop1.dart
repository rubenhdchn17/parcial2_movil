import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Shop1Page(),
    );
  }
}

class Shop1Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tienda 1'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                'assets/mapa.png',
                fit: BoxFit.cover,
                width: 375,
                height: 200, // Ajusta la altura de la primera imagen aquí
              ),
            ),
            SizedBox(
                height: 10), // Espacio entre la primera imagen y la segunda
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                'assets/mapa.png',
                fit: BoxFit.cover,
                width: 375,
                height: 200, // Ajusta la altura de la segunda imagen aquí
              ),
            ),
            SizedBox(height: 20), // Espacio entre la segunda imagen y el botón
            ElevatedButton(
              onPressed: () {
                // Lógica a ejecutar cuando se presiona el botón
              },
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                child: Text(
                  'Desmarcar ruta',
                  style: TextStyle(fontSize: 20),
                ),
              ),
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
