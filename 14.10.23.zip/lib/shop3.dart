import 'package:flutter/material.dart';

class Shop3Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalles de SuperDroguería Olímpica 93'),
      ),
      body: Center(
        child: Text(
          'McDonals',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
