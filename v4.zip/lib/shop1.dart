import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Shop1Page(),
    );
  }
}

class Shop1Page extends StatefulWidget {
  @override
  _Shop1PageState createState() => _Shop1PageState();
}

class _Shop1PageState extends State<Shop1Page> {
  bool isRouteMarked = false;
  String markedImagePath = 'assets/marcadaOlimpica.png';
  String unmarkedImagePath = 'assets/mapa.png';

  String get currentImagePath =>
      isRouteMarked ? markedImagePath : unmarkedImagePath;

  void toggleRouteMarked() {
    setState(() {
      isRouteMarked = !isRouteMarked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SuperDroguería Olímpica'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                currentImagePath,
                fit: BoxFit.cover,
                width: 330,
                height: 200,
              ),
            ),
            SizedBox(height: 10),
            Container(
              width: 330,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(20),
              ),
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SuperDroguería Olímpica 93',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Compra en superalmacenes Olimpica, tenemos grandes descuentos para ti. Cientos de articulos con grandes promociones. Precios siempre bajos.',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Dirección de la tienda: Cl 93 - #45b - 90',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Abierto: 24 horas',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Image.asset(
                    'assets/anuncio.png',
                    height: 50,
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.blue,
              ),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              child: ElevatedButton(
                onPressed: () {
                  toggleRouteMarked();
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  shadowColor: Colors.transparent,
                ),
                child: Text(
                  isRouteMarked ? 'Desmarcar Ruta' : 'Marcar Ruta',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
