import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi App de Login',
      home: Shop3Page(),
    );
  }
}

class Shop3Page extends StatefulWidget {
  @override
  _Shop3PageState createState() => _Shop3PageState();
}

class _Shop3PageState extends State<Shop3Page> {
  bool isRouteMarked = false;
  String markedImagePath = 'assets/marcadaMc.png';
  String unmarkedImagePath = 'assets/mapa.png';

  String get currentImagePath =>
      isRouteMarked ? markedImagePath : unmarkedImagePath;

  void toggleRouteMarked() {
    setState(() {
      isRouteMarked = !isRouteMarked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("McDonald's"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                currentImagePath,
                fit: BoxFit.cover,
                width: 330,
                height: 200,
              ),
            ),
            SizedBox(height: 10),
            Container(
              width: 330,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(20),
              ),
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "McDonald's Barranquilla Calle 93",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Ven ya al a McDonald's y entérate de todo lo nuevo que tenemos para ti este mes.",
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Dirección de la tienda: Cl 93 - #47 - 2',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Abierto: 24 horas',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Image.asset(
                    'assets/anuncio.png',
                    height: 50,
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.blue,
              ),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              child: ElevatedButton(
                onPressed: () {
                  toggleRouteMarked();
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.transparent,
                  shadowColor: Colors.transparent,
                ),
                child: Text(
                  isRouteMarked ? 'Desmarcar Ruta' : 'Marcar Ruta',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
