import 'package:flutter/material.dart';
import 'login.dart'; // Asegúrate de importar el archivo correcto donde está definida LoginScreen

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginScreen(), // Establece LoginScreen como la página principal
    );
  }
}
